<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class SmartAddressCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method SmartAddressCustomFieldValueModel fromArray($value)
 */
class SmartAddressCustomFieldValueModel extends BaseEnumCodeCustomFieldValueModel
{

}
