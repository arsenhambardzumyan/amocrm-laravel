<?php

namespace AmoCRM\Exceptions;

class StringCollectionKeyException extends AmoCRMApiException
{
}
