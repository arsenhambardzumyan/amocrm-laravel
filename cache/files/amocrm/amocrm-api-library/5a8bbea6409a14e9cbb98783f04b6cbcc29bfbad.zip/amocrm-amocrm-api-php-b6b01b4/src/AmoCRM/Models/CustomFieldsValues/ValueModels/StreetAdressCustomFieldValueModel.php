<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class StreetAdressCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method StreetAdressCustomFieldValueModel fromArray($value)
 */
class StreetAdressCustomFieldValueModel extends BaseCustomFieldValueModel
{

}
