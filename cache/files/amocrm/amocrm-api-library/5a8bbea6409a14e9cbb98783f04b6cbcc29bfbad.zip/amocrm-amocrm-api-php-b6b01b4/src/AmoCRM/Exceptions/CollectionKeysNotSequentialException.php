<?php

namespace AmoCRM\Exceptions;

class CollectionKeysNotSequentialException extends AmoCRMApiException
{
}
