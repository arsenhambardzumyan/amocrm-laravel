<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class DateTimeCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method DateTimeCustomFieldValueModel fromArray($value)
 */
class DateTimeCustomFieldValueModel extends DateCustomFieldValueModel
{
}
