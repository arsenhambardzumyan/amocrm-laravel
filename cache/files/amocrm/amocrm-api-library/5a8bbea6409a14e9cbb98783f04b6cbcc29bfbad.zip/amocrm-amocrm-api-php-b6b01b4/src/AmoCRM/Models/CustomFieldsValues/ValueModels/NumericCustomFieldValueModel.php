<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class NumericCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method NumericCustomFieldValueModel fromArray($value)
 */
class NumericCustomFieldValueModel extends BaseCustomFieldValueModel
{

}
