<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class LinkedEntityCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class LinkedEntityCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
