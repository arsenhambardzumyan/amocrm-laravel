<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class TextCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method TextCustomFieldValueModel fromArray($value)
 */
class TextCustomFieldValueModel extends BaseCustomFieldValueModel
{

}
