<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class CategoryCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method CategoryCustomFieldValueModel fromArray($value)
 */
class CategoryCustomFieldValueModel extends BaseEnumCustomFieldValueModel
{

}
