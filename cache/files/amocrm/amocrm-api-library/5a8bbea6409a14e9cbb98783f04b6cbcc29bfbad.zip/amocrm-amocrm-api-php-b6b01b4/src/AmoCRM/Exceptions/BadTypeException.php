<?php

namespace AmoCRM\Exceptions;

class BadTypeException extends AmoCRMApiException
{
}
