<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class MultiselectCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method MultiselectCustomFieldValueModel fromArray($value)
 */
class MultiselectCustomFieldValueModel extends BaseEnumCustomFieldValueModel
{

}
