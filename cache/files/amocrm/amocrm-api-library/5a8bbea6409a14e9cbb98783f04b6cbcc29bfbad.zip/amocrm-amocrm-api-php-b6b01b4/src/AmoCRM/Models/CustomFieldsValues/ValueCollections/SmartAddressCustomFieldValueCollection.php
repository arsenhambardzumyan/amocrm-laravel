<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class SmartAddressCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class SmartAddressCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
