<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class BirthdayCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method BirthdayCustomFieldValueModel fromArray($value)
 */
class BirthdayCustomFieldValueModel extends DateCustomFieldValueModel
{

}
