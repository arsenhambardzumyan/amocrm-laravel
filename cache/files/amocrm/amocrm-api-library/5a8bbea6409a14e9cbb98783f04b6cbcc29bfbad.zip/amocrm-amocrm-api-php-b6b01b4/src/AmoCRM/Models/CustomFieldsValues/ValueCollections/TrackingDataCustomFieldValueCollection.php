<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class TrackingDataCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class TrackingDataCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
