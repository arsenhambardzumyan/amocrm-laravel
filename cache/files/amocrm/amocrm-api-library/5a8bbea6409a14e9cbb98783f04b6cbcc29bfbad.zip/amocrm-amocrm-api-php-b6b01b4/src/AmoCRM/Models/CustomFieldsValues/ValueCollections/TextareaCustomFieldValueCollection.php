<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class TextareaCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class TextareaCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
