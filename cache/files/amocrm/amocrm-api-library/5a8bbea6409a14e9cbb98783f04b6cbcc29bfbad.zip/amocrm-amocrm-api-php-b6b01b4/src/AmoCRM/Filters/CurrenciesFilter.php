<?php

declare(strict_types=1);

namespace AmoCRM\Filters;

/**
 * @since Release Spring 2022
 */
class CurrenciesFilter extends PagesFilter
{
}
