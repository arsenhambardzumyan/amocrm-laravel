<?php

namespace AmoCRM\Exceptions;

/**
 * Class AmoCRMoAuthApiException
 *
 * Выбрасывается в случае ошибки при работе с oAuth amoCRM
 *
 * @package AmoCRM\Exceptions
 */
class AmoCRMoAuthApiException extends AmoCRMApiException
{
}
