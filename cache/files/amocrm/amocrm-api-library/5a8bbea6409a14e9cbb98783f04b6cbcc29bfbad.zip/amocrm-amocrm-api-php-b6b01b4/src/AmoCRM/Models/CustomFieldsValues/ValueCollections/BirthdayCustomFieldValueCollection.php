<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class BirthdayCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class BirthdayCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
