<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * @method MonetaryCustomFieldValueModel fromArray($value)
 * @since Release Spring 2022
 */
class MonetaryCustomFieldValueModel extends BaseCustomFieldValueModel
{
}
