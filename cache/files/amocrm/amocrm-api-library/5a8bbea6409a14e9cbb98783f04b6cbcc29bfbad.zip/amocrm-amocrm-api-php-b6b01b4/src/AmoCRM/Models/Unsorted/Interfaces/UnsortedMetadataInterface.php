<?php

namespace AmoCRM\Models\Unsorted\Interfaces;

interface UnsortedMetadataInterface
{
    /**
     * @return array
     */
    public function toArray(): array;
}
