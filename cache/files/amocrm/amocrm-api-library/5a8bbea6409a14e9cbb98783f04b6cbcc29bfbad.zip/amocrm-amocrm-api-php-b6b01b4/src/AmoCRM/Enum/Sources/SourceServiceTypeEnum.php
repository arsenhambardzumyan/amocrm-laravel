<?php

declare(strict_types=1);

namespace AmoCRM\Enum\Sources;

class SourceServiceTypeEnum
{
    public const TYPE_WHATSAPP = 'whatsapp';
}
