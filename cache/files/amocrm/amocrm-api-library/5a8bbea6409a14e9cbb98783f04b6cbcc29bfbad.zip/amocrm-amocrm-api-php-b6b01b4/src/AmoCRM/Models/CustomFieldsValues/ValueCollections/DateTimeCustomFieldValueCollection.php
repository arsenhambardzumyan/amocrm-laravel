<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class DateTimeCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class DateTimeCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
