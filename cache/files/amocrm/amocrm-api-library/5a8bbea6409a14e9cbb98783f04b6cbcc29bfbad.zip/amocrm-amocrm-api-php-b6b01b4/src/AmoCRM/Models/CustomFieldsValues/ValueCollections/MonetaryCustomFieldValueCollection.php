<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * @since Release Spring 2022
 */
class MonetaryCustomFieldValueCollection extends BaseCustomFieldValueCollection
{
}
