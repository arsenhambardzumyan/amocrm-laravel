<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueModels;

/**
 * Class SelectCustomFieldValueModel
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueModels
 *
 * @method SelectCustomFieldValueModel fromArray($value)
 */
class SelectCustomFieldValueModel extends BaseEnumCodeCustomFieldValueModel
{
}
