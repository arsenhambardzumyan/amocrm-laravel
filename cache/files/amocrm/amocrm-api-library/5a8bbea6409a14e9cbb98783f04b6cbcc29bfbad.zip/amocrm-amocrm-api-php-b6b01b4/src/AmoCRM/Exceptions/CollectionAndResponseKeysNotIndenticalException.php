<?php

namespace AmoCRM\Exceptions;

class CollectionAndResponseKeysNotIndenticalException extends AmoCRMApiException
{
}
