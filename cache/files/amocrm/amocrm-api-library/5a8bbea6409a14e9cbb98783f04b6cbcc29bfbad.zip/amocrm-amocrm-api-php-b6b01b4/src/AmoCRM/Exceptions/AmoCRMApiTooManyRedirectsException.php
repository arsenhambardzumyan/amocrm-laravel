<?php

namespace AmoCRM\Exceptions;

/**
 * Class AmoCRMApiTooManyRedirectsException
 *
 * @package AmoCRM\Exceptions
 */
class AmoCRMApiTooManyRedirectsException extends AmoCRMApiException
{
}
