<?php

namespace AmoCRM\Models\CustomFieldsValues\ValueCollections;

/**
 * Class PriceCustomFieldValueCollection
 *
 * @package AmoCRM\Models\CustomFieldsValues\ValueCollections
 */
class PriceCustomFieldValueCollection extends BaseCustomFieldValueCollection
{

}
